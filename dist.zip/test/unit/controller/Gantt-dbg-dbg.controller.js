/*global QUnit*/

sap.ui.define([
	"dbr75126/dbr75126/controller/Gantt.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Gantt Controller");

	QUnit.test("I should test the Gantt controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});