sap.ui.define([
	"dbr75126/dbr75126/test/unit/controller/Gantt.controller"
], function () {
	"use strict";
});