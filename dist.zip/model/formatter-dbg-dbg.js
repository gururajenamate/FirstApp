sap.ui.define([], function () {

	return {
		formatDate: function (val) {
			v
		}
	};
});