sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/gantt/def/cal/Calendar",
	"sap/gantt/def/cal/CalendarDefs",
	"sap/gantt/def/cal/TimeInterval",
	"sap/gantt/config/TimeHorizon",
	"sap/gantt/axistime/ProportionZoomStrategy",
	"sap/gantt/shape/Group",
	"sap/gantt/shape/Rectangle",
	"sap/gantt/shape/SelectedShape",
	"sap/gantt/shape/ext/Diamond",
	"sap/gantt/shape/ext/Triangle",
	"sap/ui/table/plugins/MultiSelectionPlugin",
	"sap/gantt/shape/ext/rls/Relationship",
	"sap/gantt/shape/cal/Calendar",
	"sap/gantt/shape/ext/Chevron",
	"dbr75126/dbr75126/model/formatter",
	'sap/viz/ui5/format/ChartFormatter',
	'sap/viz/ui5/api/env/Format',
	'sap/ui/model/BindingMode',
	"dbr75126/dbr75126/controller/InitPage",
], function (Controller, MessageToast, JSONModel,
	Calendar,
	CalendarDefs,
	TimeInterval,
	TimeHorizon,
	ProportionZoomStrategy,
	Group,
	Rectangle,
	SelectedShape,
	Diamond,
	Triangle,
	MultiSelectionPlugin, Chevron, formatter, ChartFormatter, Format, BindingMode, InitPageUtil) {
	"use strict";
	jQuery.sap.require("sap.gantt.def.cal.Calendar");
	jQuery.sap.require("sap.gantt.def.cal.CalendarDefs");
	jQuery.sap.require("sap.gantt.def.cal.TimeInterval");

	var oDarkThemes = {
		"sap_hcb": true,
		"sap_fiori_3_dark": true,
		"sap_fiori_3_hcb": true,
		"sap_belize_hcb": true
	};

	return Controller.extend("dbr75126.dbr75126.controller.Gantt", {
		formatter: formatter,
		onInit: function () {
			this.loadLineChart();

			this.setGanttChart();
			this.getDropdown();

			this.loadCostingChart();

			var date = new Date();
			this.getView().byId("DRS2").setMinDate(date);

			var sPath = jQuery.sap.getModulePath("dbr75126.dbr75126", "/controller/workCenter.json");
			var workCenterModel = new sap.ui.model.json.JSONModel(sPath);
			this.getView().setModel(workCenterModel, "workCenterModel");

		},

		loadCostingChart: function (oEvt) {
			var oModel = new JSONModel(this.settingsModel);
			this.getView().setModel(oModel);

			var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrame");

			if (oEvt) {
				if (oEvt.getSource().getId().split("--")[2] === "chartType") {
					if (oEvt === undefined) {
						oVizFrame.setVizType("stacked_bar");
					} else {
						oVizFrame.setVizType(oEvt.getSource().getSelectedKey());
					}
				}
			} else {
				oVizFrame.setVizType("stacked_bar");
			}

			oVizFrame.setVizProperties({
				title: {
					visible: true,
					text: 'Costing Data'
				}
			});
			// var sPath = jQuery.sap.getModulePath("dbr75126.dbr75126", "/controller/costingDataChart.json");
			var dataModel = this.getOwnerComponent().getModel("costingChartModel");
			if (oEvt) {
				if (oEvt.getSource().getId().split("--")[2] === "recordsNum") {
					if (oEvt.getSource().getSelectedKey() === "10") {
						var top10 = dataModel.getData().milk.sort(function (a, b) {
								return parseInt(a.TOTAL) < parseInt(b.TOTAL) ? 1 : -1;
							})
							.slice(0, 10);
						dataModel.setData({
							"milk": top10
						});
						oVizFrame.setModel(dataModel, "costingChartModel");
						this.getView().setModel(dataModel, "costingChartModel");
					} else {
						var dataModel = this.getOwnerComponent().getModel("completeCostingChartModel");

						oVizFrame.setModel(dataModel, "costingChartModel");
						this.getView().setModel(dataModel, "costingChartModel");
					}
				}
			} else {
				oVizFrame.setModel(dataModel, "costingChartModel");
				this.getView().setModel(dataModel, "costingChartModel");
			}

			var oPopOver = this.getView().byId("idPopOver");
			oPopOver.connect(oVizFrame.getVizUid());
		},

		loadLineChart: function (oEvt) {
			var oModel = new JSONModel(this.settingsModel);
			this.getView().setModel(oModel);

			if (oEvt) {
				if (oEvt.getSource().getSelectedKey() === "2020") {
					var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrameLine2020");
					this.getView().byId("chartFixFlexLine2020").setVisible(true);
					this.getView().byId("chartFixFlexLine2021").setVisible(false);
					var oPopOver = this.getView().byId("idPopOverLine");
					oPopOver.connect(oVizFrame.getVizUid());
				} else {
					var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrameLine2021");
					this.getView().byId("chartFixFlexLine2021").setVisible(true);
					this.getView().byId("chartFixFlexLine2020").setVisible(false);
					var oPopOver = this.getView().byId("idPopOverLine2021");
					oPopOver.connect(oVizFrame.getVizUid());
				}
			} else {
				var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrameLine2020");
				this.getView().byId("chartFixFlexLine2020").setVisible(true);
				this.getView().byId("chartFixFlexLine2021").setVisible(false);
				var oPopOver = this.getView().byId("idPopOverLine");
				oPopOver.connect(oVizFrame.getVizUid());
			}

			oVizFrame.setVizProperties({
				title: {
					visible: true,
					text: 'Utilization Data'
				}
			});
			var sPath = jQuery.sap.getModulePath("dbr75126.dbr75126", "/controller/workCenter.json");
			var dataModel = new JSONModel(sPath);
			oVizFrame.setModel(dataModel, "lineChartModel");
			this.getView().setModel(dataModel, "lineChartModel");

		},

		changeStartDate: function (oEvt) {
			var a = oEvt.getSource();
		},

		changeYear: function (oEvt) {
			var getSelItem = oEvt.getSource().getSelectedKey();
			if (getSelItem === "2020") {
				this.getView().byId("table2020").setVisible(true);
				this.getView().byId("table2021").setVisible(false);
			} else {
				this.getView().byId("table2020").setVisible(false);
				this.getView().byId("table2021").setVisible(true);
			}
		},

		getGanttChartFragmemt: function () {
			var oGanttChartContainer = sap.ui.getCore().byId("GanttChartContainerFrag");
			var oGanttChartWithTable = oGanttChartContainer.getGanttCharts()[0];
			// var sPath = jQuery.sap.getModulePath("dbr75126.dbr75126", "/controller/data.json");
			var sPath = jQuery.sap.getModulePath("dbr75126.dbr75126", "/controller/ganttData.json");
			this._oModel = new JSONModel();
			var that = this;
			jQuery.ajax({
				url: sPath
			}).then(function (data) {

				for (var i = 0; i < data.length; i++) {
					data[i].id = "00" + (i + 1);
					data[i].level = "01";
					var st = data[i].Start.split(".");
					var et = data[i].End.split(".");
					data[i].order = [{
						"startTime": st[2] + st[1] + st[0] + "000000",
						"endTime": et[2] + et[1] + et[0] + "000000",
						"level": "1",
						"Procstatus": "Due"
					}];

				}

				var oData = {
					"root": {
						"id": "root",
						"level": "root",
						"children": data
					}
				};

				that._oModel.setData(oData);
				// configuration of GanttChartContainer
				oGanttChartContainer.setModel(that._oModel, "test");
				oGanttChartContainer.setLegendContainer(that._createLegendContainer());
				oGanttChartContainer.setContainerLayouts(that._createContainerLayouts());
				oGanttChartContainer.setContainerLayoutKey("sap.gantt.sample.gantt_layout");
				oGanttChartContainer.addCustomToolbarItem(that._createCustomToolbar());

				// configuration of GanttChartWithTable
				oGanttChartWithTable.bindAggregation("rows", {
					path: "test>/root",
					parameters: {
						arrayNames: ["children"]
					}
				});

				oGanttChartWithTable.setAxisTimeStrategy(that._createZoomStrategy());
				oGanttChartWithTable.setShapeDataNames(["top", "order", "milestone", "constraint", "relationship", "nwt", "nwtForWeekends"]);
				oGanttChartWithTable.setShapes(that._configShape());
				var oSelectionPlugin = new MultiSelectionPlugin();
				oGanttChartWithTable.getAggregation("_chart").getAggregation("_treeTable").addPlugin(oSelectionPlugin);
				oGanttChartWithTable.getAggregation("_selectionPanel").addPlugin(oSelectionPlugin);
				oGanttChartWithTable.setSelectionMode(sap.gantt.SelectionMode.None);
			});
		},

		closeDialog: function () {
			this.dialog.close();
			this.dialog.destroy();
		},

		getDropdown: function () {

			var sPath = jQuery.sap.getModulePath("dbr75126.dbr75126", "/controller/ganttData.json");
			this._oModel = new JSONModel();
			var that = this;
			jQuery.ajax({
				url: sPath
			}).then(function (data) {
				var dropdown = new JSONModel();
				var funcArray = [];
				for (var i = 0; i < data.length; i++) {
					funcArray.push(data[i].FuncLoc);
				}
				var uniqueArray = [];
				for (i = 0; i < funcArray.length; i++) {
					if (uniqueArray.indexOf(funcArray[i]) === -1) {
						uniqueArray.push(funcArray[i]);
					}
				}
				var uniqueArrayKey = [];
				for (i = 0; i < uniqueArray.length; i++) {
					uniqueArrayKey.push({
						funcLoc: uniqueArray[i]
					});
				}
				dropdown.setData(uniqueArrayKey);
				that.getView().setModel(dropdown, "dropdown");
			});

		},

		setGanttChart: function () {
			var oGanttChartContainer = this.getView().byId("GanttChartContainer");
			var oGanttChartWithTable = oGanttChartContainer.getGanttCharts()[0];
			// var sPath = jQuery.sap.getModulePath("dbr75126.dbr75126", "/controller/data.json");
			var sPath = jQuery.sap.getModulePath("dbr75126.dbr75126", "/controller/ganttData.json");
			this._oModel = new JSONModel();
			var that = this;
			jQuery.ajax({
				url: sPath
			}).then(function (data) {

				for (var i = 0; i < data.length; i++) {
					data[i].id = "00" + (i + 1);
					data[i].level = "01";
					var st = data[i].Start.split(".");
					var et = data[i].End.split(".");
					data[i].StartDate = new Date(st[1] + "/" + st[0] + "/" + st[2]);
					data[i].EndDate = new Date(et[1] + "/" + et[0] + "/" + et[2]);
					data[i].order = [{
						"startTime": st[2] + st[1] + st[0] + "000000",
						"endTime": et[2] + et[1] + et[0] + "000000",
						"level": "1",
						"Procstatus": "Due",
						"item": data[i].ORDERITEM
					}];

				}

				var oData = {
					"root": {
						"id": "root",
						"level": "root",
						"children": data
					}
				};

				that._oModel.setData(oData);
				// configuration of GanttChartContainer
				oGanttChartContainer.setModel(that._oModel, "test");
				var techObjs = [];
				if (that.getView().byId("techObjId").getSelectedItems().length > 0 || that.getView().byId("DRS2").getValue()) {
					var totalLength = oData.root.children.length;
					var getSelData = that.getView().byId("techObjId").getSelectedItems();
					var dateRange = that.getView().byId("DRS2").getValue();

					for (var i = 0; i < getSelData.length; i++) {
						techObjs.push(getSelData[i].getText());
					}
					if (dateRange) {
						var st = that.getView().byId("DRS2").getDateValue().getTime(); //dateRange.split(" ")[0].split("-");
						var et = that.getView().byId("DRS2").getSecondDateValue().getTime();
						var startTime = st;
						var endTime = et;

						var finalArray = [];
						var filterBy = {
							FuncLoc: techObjs,
							startTime: [startTime],
							endTime: [endTime]
						};

						var result = oData.root.children.filter(function (o) {
							return (techObjs.length > 0 && techObjs.indexOf(o.FuncLoc) !== -1) || (o.StartDate.getTime() >= filterBy.startTime[0] && o.EndDate
								.getTime() <=
								filterBy.endTime[
									0]);
						});
					} else {
						var finalArray = [];
						var filterBy = {
							FuncLoc: techObjs
						};

						var result = oData.root.children.filter(function (o) {
							return (techObjs.length > 0 && techObjs.indexOf(o.FuncLoc) !== -1);
						});

					}

					// console.log(result);

					var oData = {
						"root": {
							"id": "root",
							"level": "root",
							"children": result
						}
					};

					that._oModel.setData(oData);
					// configuration of GanttChartContainer
					oGanttChartContainer.setModel(that._oModel, "test");

				}

				var costingChartRresult = that.getView().getModel("costingChartModel").getData().milk.filter(function (o) {
					return (techObjs.length > 0 && techObjs.indexOf(o.FuncLoc) !== -1);
				});
				// oVizFrame.setModel(dataModel, "costingChartModel");
				var costingChartModel = new sap.ui.model.json.JSONModel();
				costingChartModel.setData({
					"milk": costingChartRresult
				});
				var oVizFrame = that.getView().byId("idVizFrame");
				oVizFrame.setModel(costingChartModel, "costingChartModel");
				that.getView().setModel(costingChartModel, "costingChartModel");

				oGanttChartContainer.setLegendContainer(that._createLegendContainer());
				oGanttChartContainer.setToolbarSchemes(that._createToolbarSchemes());
				oGanttChartContainer.setContainerLayouts(that._createContainerLayouts());
				oGanttChartContainer.setContainerLayoutKey("sap.gantt.sample.gantt_layout");
				oGanttChartContainer.addCustomToolbarItem(that._createCustomToolbar());
				oGanttChartWithTable.setSelectionPanelSize("35%");

				// configuration of GanttChartWithTable
				oGanttChartWithTable.bindAggregation("rows", {
					path: "test>/root",
					parameters: {
						arrayNames: ["children"]
					}
				});

				oGanttChartWithTable.setAxisTimeStrategy(that._createZoomStrategy());
				oGanttChartWithTable.setShapeDataNames(["top", "order", "milestone", "constraint", "relationship", "nwt", "nwtForWeekends"]);
				oGanttChartWithTable.setShapes(that._configShape());
				var oSelectionPlugin = new MultiSelectionPlugin();
				oGanttChartWithTable.getAggregation("_chart").getAggregation("_treeTable").addPlugin(oSelectionPlugin);
				oGanttChartWithTable.getAggregation("_selectionPanel").addPlugin(oSelectionPlugin);
				oGanttChartWithTable.setSelectionMode(sap.gantt.SelectionMode.None);
			});
		},

		_checkSelectedRow: function (aSelectedRows) {
			if (aSelectedRows.length >= 1) {
				return true;
			} else {
				MessageToast.show("Plase select one or more rows");
				return false;
			}
		},

		handleDateChange: function (event) {
			var oDatePicker = event.getSource();
			var aCells = oDatePicker.getParent().getCells();

			if (oDatePicker === oDatePicker.getParent().getCells()[1]) {
				this._checkDate(aCells[1], aCells[2], true);
			} else {
				this._checkDate(aCells[1], aCells[2], false);
			}
		},

		/*
		 * Check Date.
		 * @private
		 * @param {Object} startCell, {Object} endCell, {Boolean} bIsChangeStart
		 * @returns undefined
		 */
		_checkDate: function (startCell, endCell, bIsChangeStart) {
			if (bIsChangeStart === undefined) {
				jQuery.sap.log.error("bIsChangeStart is not defined!");
				return;
			}

			if (startCell.getValue() > endCell.getValue()) {
				this._showNotAllowedMsg();
				if (bIsChangeStart) {
					startCell.setValue(endCell.getValue());
				} else {
					endCell.setValue(startCell.getValue());
				}
			}
		},

		/*
		 * Show "Not Allowed" message.
		 * @private
		 * @returns undefined
		 */
		_showNotAllowedMsg: function () {
			MessageToast.show("Not allowed");
		},

		/*
		 * Handle event of shapeDragEnd
		 * @public
		 * @param {Object} [oEvent] event context
		 * @returns {Boolean} if Drag and Drop succeed
		 */
		handleShapeDragEnd: function (oEvent) {
			var oParam = oEvent.getParameters();
			var aSourceShapeData = oParam.sourceShapeData;
			var oSourceShapeData = aSourceShapeData[0].shapeData;
			var sSourceId = aSourceShapeData[0].objectInfo.id;
			var oTargetData = oParam.targetData;

			//change the form of date from millis to timestamp
			var sTarStartTime = sap.gantt.misc.Format.dateToAbapTimestamp(new Date(oTargetData.mouseTimestamp.startTime));
			var sTarEndTime = sap.gantt.misc.Format.dateToAbapTimestamp(new Date(oTargetData.mouseTimestamp.endTime));

			if (!oTargetData.objectInfo) {
				this._showNotAllowedMsg();
				return false;
			}

			var sTargetId = oTargetData.objectInfo.id;

			if (this._checkDropSameRow(sSourceId, sTargetId) && this._selectOnlyOneRow(aSourceShapeData)) {
				//oSourceShapeData is a reference, so we only need to change startTime and endTime, then reset data model
				oSourceShapeData.startTime = sTarStartTime;
				oSourceShapeData.endTime = sTarEndTime;
				var oModelData = this._oModel.getData();
				this._oModel.setData(oModelData);
				return true;
			} else {
				this._showNotAllowedMsg();
				return false;
			}
		},

		/*
		 * Check if drop the selected task to the same row
		 * @private
		 * @param {String} [sSourceId] source id
		 * @param {String} [sTargetId] target id
		 * @returns {Boolean} if drop the selected task in the same row
		 */
		_checkDropSameRow: function (sSourceId, sTargetId) {
			if (sSourceId === sTargetId) {
				return true;
			} else {
				return false;
			}
		},

		/*
		 * Check if only select one row of chart
		 * @private
		 * @param {Array} [aSourceShapeData] array of source data
		 * @returns {Boolean} if only select one row of chart
		 */
		_selectOnlyOneRow: function (aSourceShapeData) {
			if (aSourceShapeData.length === 1) {
				return true;
			} else {
				return false;
			}
		},

		/*
		 * Create Zoom Strategy
		 * @private
		 * @returns {Object} oZoomStrategy
		 */
		_createZoomStrategy: function () {
			var oTimeLineOptions = {
				"1day": {
					innerInterval: {
						unit: sap.gantt.config.TimeUnit.day,
						span: 1,
						range: 90
					},
					largeInterval: {
						unit: sap.gantt.config.TimeUnit.week,
						span: 1,
						pattern: "LLL yyyy,'Week' ww"
					},
					smallInterval: {
						unit: sap.gantt.config.TimeUnit.day,
						span: 1,
						pattern: "EEE dd"
					}
				},
				"1week": {
					innerInterval: {
						unit: sap.gantt.config.TimeUnit.week,
						span: 1,
						range: 90
					},
					largeInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 1,
						pattern: "LLLL yyyy"
					},
					smallInterval: {
						unit: sap.gantt.config.TimeUnit.week,
						span: 1,
						pattern: "'CW' w"
					}
				},
				"1month": {
					innerInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 1,
						range: 90
					},
					largeInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 3,
						pattern: "yyyy, QQQ"
					},
					smallInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 1,
						pattern: "LLL"
					}
				},
				"1quarter": {
					innerInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 3,
						range: 90
					},
					largeInterval: {
						unit: sap.gantt.config.TimeUnit.year,
						span: 1,
						pattern: "yyyy"
					},
					smallInterval: {
						unit: sap.gantt.config.TimeUnit.month,
						span: 3,
						pattern: "QQQ"
					}
				},
				"1year": {
					innerInterval: {
						unit: sap.gantt.config.TimeUnit.year,
						span: 1,
						range: 90
					},
					largeInterval: {
						unit: sap.gantt.config.TimeUnit.year,
						span: 10,
						pattern: "yyyy"
					},
					smallInterval: {
						unit: sap.gantt.config.TimeUnit.year,
						span: 1,
						pattern: "yyyy"
					}
				}
			};

			return new ProportionZoomStrategy({
				totalHorizon: new TimeHorizon({
					startTime: "20200101000000",
					endTime: "20210901000000"
				}),
				visibleHorizon: new TimeHorizon({
					startTime: "20200814000000",
					endTime: "20200930000000"
				}),
				timeLineOptions: oTimeLineOptions,
				timeLineOption: oTimeLineOptions["1week"],
				coarsestTimeLineOption: oTimeLineOptions["1year"],
				finestTimeLineOption: oTimeLineOptions["1day"]
			});
		},

		onAfterRendering: function () {
			setTimeout(function () {
				var oGanttChartContainer = this.getView().byId("GanttChartContainer");
				var oGanttChartWithTable = oGanttChartContainer.getGanttCharts()[0];
				oGanttChartWithTable.jumpToPosition(new Date("2020-09-14"));
				// sap.ui.getCore().byId("__xmlview0--GanttChartContainer").setTimeZoomRate(1);
			}.bind(this), 1000);

			var feedValueAxis = this.getView().byId('valueAxisFeed');
			this.oVizFrame.removeFeed(feedValueAxis);
			feedValueAxis.setValues(["Sum of Stock Material", "Sum of Ext Material", "Sum of Labor", "Sum of Services", "Sum of Oth"]);
			this.oVizFrame.addFeed(feedValueAxis);
		},

		createTask: function () {
			var oGanttChartContainer = this.getView().byId("GanttChartContainer");
			var aSelectedRows = oGanttChartContainer.getSelectedRows(0)[0].selectedRows;

			if (this._checkSelectedRow(aSelectedRows)) {
				this._addRows(aSelectedRows);
			}
			var aIds = [];
			for (var i = 0; i < aSelectedRows.length; i++) {
				aIds.push(aSelectedRows[i].id);
			}
			setTimeout(function () {
				oGanttChartContainer.deselectRows(0);
				oGanttChartContainer.selectRows(0, aIds); //reselect rows
			}, 300);
		},

		deleteTask: function () {
			var oGanttChartContainer = this.getView().byId("GanttChartContainer");
			var aSelectedRows = oGanttChartContainer.getSelectedRows(1)[0].selectedRows;

			if (this._checkSelectedRow(aSelectedRows)) {
				this._deleteRows(aSelectedRows);
				this._clearSelection();
			}
		},

		_createCustomToolbar: function () {
			return new sap.m.Toolbar({
				content: [
					new sap.m.ToolbarSpacer(),
					new sap.m.ToolbarSeparator()
				]
			});
		},

		/*
		 * Create ToolbarSchemes
		 * @private
		 * @returns {Array} aToolbarSchemes
		 */
		_createToolbarSchemes: function () {
			this._oSettingsGroup = new sap.gantt.config.SettingGroup({
				// id: "settingsGroup",
				position: "R1",
				overflowPriority: sap.m.OverflowToolbarPriority.Low,
				items: sap.gantt.config.DEFAULT_TOOLBAR_SETTING_ITEMS
			});
			return [
				new sap.gantt.config.ToolbarScheme({
					key: "GLOBAL_TOOLBAR",
					customToolbarItems: new sap.gantt.config.ToolbarGroup({
						position: "R2",
						overflowPriority: sap.m.OverflowToolbarPriority.High
					}),
					timeZoom: new sap.gantt.config.ToolbarGroup({
						position: "R4",
						overflowPriority: sap.m.OverflowToolbarPriority.NeverOverflow
					}),
					legend: new sap.gantt.config.ToolbarGroup({
						position: "R3",
						overflowPriority: sap.m.OverflowToolbarPriority.Low
					}),
					settings: this._oSettingsGroup,
					toolbarDesign: sap.m.ToolbarDesign.Transparent
				}),
				new sap.gantt.config.ToolbarScheme({
					key: "LOCAL_TOOLBAR"
				})
			];
		},

		/*
		 * Create ContainerLayouts
		 * @private
		 * @returns {Array} aContainerLayouts
		 */
		_createContainerLayouts: function () {
			return [
				new sap.gantt.config.ContainerLayout({
					key: "sap.gantt.sample.gantt_layout",
					text: "Gantt Layout",
					toolbarSchemeKey: "GLOBAL_TOOLBAR"
				})
			];
		},

		/*
		 * Create Legend
		 * @private
		 * @returns {Object} oLegend
		 */
		_createLegendContainer: function () {
			var sSumTaskColor = "#FAC364";
			var sTasksColor = "#5CBAE5";
			var sRelColor = "#848F94";
			var sTheme = sap.ui.getCore().getConfiguration().getTheme();
			var sTextColor = oDarkThemes[sTheme] === true ? "white" : "";
			var oLegend = new sap.gantt.legend.LegendContainer({
				legendSections: [
					new sap.m.Page({
						title: "Legend",
						content: [
							new sap.ui.core.HTML({
								content: "<div width='100%' height='50%' style='margin-top: 25px'><svg width='180px' height='60px'><g>" +
									"<g style='display: block;'>" +
									"<g><rect x='" + (sap.ui.getCore().getConfiguration().getRTL() ? "155" : "25") + "' y='2' width='20' height='20' fill=" +
									sSumTaskColor + " style='stroke: " + sSumTaskColor + "; stroke-width: 2px;'></rect>" +
									"<text x='" + (sap.ui.getCore().getConfiguration().getRTL() ? "125" : "55") + "' y='16' font-size='0.875rem' fill=" +
									sTextColor + ">EXISTING ORDER</text></g>" +
									"<g><rect x='" + (sap.ui.getCore().getConfiguration().getRTL() ? "155" : "25") +
									"' y='32' width='20' height='20' fill=" + sTasksColor + " style='stroke: " + sTasksColor +
									"; stroke-width: 2px;'></rect>" +
									"<text x='" + (sap.ui.getCore().getConfiguration().getRTL() ? "125" : "55") + "' y='46' font-size='0.875rem' fill=" +
									sTextColor + ">PREVENTIVE MAINTENANCE CALL</text></g>" +
									"</g></g></svg></div>"
							})
						]
					})
				]
			});

			return oLegend;
		},
		onReset: function (oEvent) {
			var sMessage = "onReset trigered";
			MessageToast.show(sMessage);
		},

		onSearch: function (oEvent) {
			var sMessage = "onSearch trigered";
			MessageToast.show(sMessage);
		},

		_configShape: function () {
			var aShapes = [];

			//
			Group.extend("sap.gantt.sample.RectangleGroup", {
				getRLSAnchors: function (oRawData, oObjectInfo) {
					var shapes = this.getShapes();
					var rectangleShapeClass;
					var _x, _y;

					for (var i in shapes) {
						if (shapes[i] instanceof sap.gantt.shape.Rectangle) {
							rectangleShapeClass = shapes[i];
						}
					}

					_x = rectangleShapeClass.getX(oRawData);
					_y = rectangleShapeClass.getY(oRawData, oObjectInfo) + rectangleShapeClass.getHeight() / 2;

					return {
						startPoint: {
							x: _x,
							y: _y,
							height: rectangleShapeClass.getHeight(oRawData)
						},
						endPoint: {
							x: _x + rectangleShapeClass.getWidth(oRawData),
							y: _y,
							height: rectangleShapeClass.getHeight(oRawData)
						}
					};
				}
			});

			/**/
			Rectangle.extend("sap.gantt.sample.shapeRectangle", {
				getFill: function (oRawData) {
					switch (oRawData.item) {
					case "CALL":
						return "#5CBAE5";
					default:
						return "#FAC364";
					}
				}
			});

			SelectedShape.extend("sap.gantt.sample.selectRectange", {
				getStroke: function (oRowData) {
					switch (oRowData.item) {
					case "CALL":
						return "#B57506";
					default:
						return "#156589";
					}
				},
				getStrokeWidth: function () {
					return 2;
				}
			});

			Diamond.extend("sap.gantt.sample.Milestone");

			Triangle.extend("sap.gantt.sample.Constraint");

			var oTopShape = new sap.gantt.config.Shape({
				key: "top",
				shapeDataName: "order",
				shapeClassName: "sap.gantt.sample.shapeRectangle",
				selectedClassName: "sap.gantt.sample.selectRectange",
				level: 5,
				shapeProperties: {
					time: "{startTime}",
					endTime: "{endTime}",
					height: 20,
					isDuration: true,
					enableDnD: true
				}
			});

			var oOrderShape = new sap.gantt.config.Shape({
				key: "order",
				shapeDataName: "order",
				shapeClassName: "sap.gantt.sample.RectangleGroup",
				selectedClassName: "sap.gantt.sample.selectRectange",
				level: 5,
				shapeProperties: {
					time: "{startTime}",
					endTime: "{endTime}",
					height: 20,
					isDuration: true,
					enableDnD: true
				},
				groupAggregation: [
					new sap.gantt.config.Shape({
						shapeClassName: "sap.gantt.sample.shapeRectangle",
						selectedClassName: "sap.gantt.sample.selectRectange",
						shapeProperties: {
							time: "{startTime}",
							endTime: "{endTime}",
							title: "{tooltip}",
							height: 20,
							isDuration: true,
							enableDnD: true
						}
					})
				]
			});
			// define a milestone config
			var oDiamondConfig = new sap.gantt.config.Shape({
				key: "diamond",
				shapeClassName: "sap.gantt.sample.Milestone",
				shapeDataName: "milestone",
				level: 5,
				shapeProperties: {
					time: "{endTime}",
					strokeWidth: 2,
					title: "{tooltip}",
					verticalDiagonal: 18,
					horizontalDiagonal: 18,
					yBias: -1,
					fill: "#666666"
				}
			});
			// define a constraint config
			var oTriangleConfig = new sap.gantt.config.Shape({
				key: "triangle",
				shapeClassName: "sap.gantt.sample.Constraint",
				shapeDataName: "constraint",
				level: 5,
				shapeProperties: {
					time: "{time}",
					strokeWidth: 1,
					title: "{tooltip}",
					fill: "#666666",
					rotationAngle: "{ratationAngle}",
					base: 6,
					height: 6,
					distanceOfyAxisHeight: 3,
					yBias: 7
				}
			});

			var oRelShape = new sap.gantt.config.Shape({
				key: "relationship",
				shapeDataName: "relationship",
				level: 30,
				shapeClassName: "sap.gantt.shape.ext.rls.Relationship",
				shapeProperties: {
					isDuration: false,
					lShapeforTypeFS: true,
					showStart: false,
					showEnd: true,
					stroke: "#848F94",
					strokeWidth: 1,
					type: "{relation_type}",
					fromObjectPath: "{fromObjectPath}",
					toObjectPath: "{toObjectPath}",
					fromDataId: "{fromDataId}",
					toDataId: "{toDataId}",
					fromShapeId: "{fromShapeId}",
					toShapeId: "{toShapeId}",
					title: "{tooltip}",
					id: "{guid}"
				}
			});

			var oCalendarConfig = new sap.gantt.config.Shape({
				key: "nwt",
				shapeClassName: "sap.gantt.shape.cal.Calendar",
				shapeDataName: "nwt",
				level: 32,
				shapeProperties: {
					calendarName: "{id}"
				}
			});

			var oCalendarConfigForWeekends = new sap.gantt.config.Shape({
				key: "nwtForWeekends",
				shapeClassName: "sap.gantt.shape.cal.Calendar",
				shapeDataName: "nwtForWeekends",
				level: 32,
				shapeProperties: {
					calendarName: "{id}"
				}
			});

			aShapes = [oTopShape, oOrderShape, oDiamondConfig, oTriangleConfig, oRelShape, oCalendarConfig, oCalendarConfigForWeekends];

			return aShapes;
		},
	});
});